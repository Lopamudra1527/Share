package com.intern.major;

public class BuyingDetailsService {

}
