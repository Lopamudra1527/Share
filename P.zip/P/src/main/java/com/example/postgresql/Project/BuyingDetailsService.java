package com.example.postgresql.Project;

public class BuyingDetailsService {

}
