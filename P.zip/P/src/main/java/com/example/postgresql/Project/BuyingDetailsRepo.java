package com.example.postgresql.Project;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BuyingDetailsRepo extends JpaRepository<BuyingDetails,Long>{
	
	
}
