package com.example.postgresql.Project;

import java.security.SecureRandom;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.intern.major.GlobalData;

@Controller
public class AppController {

	@Autowired
	private UserRepository userRepo;

	@GetMapping("/landing")
	public String viewHomePage() {
		return "landing";
	}

	@GetMapping("/home")
	public String home(Model model)
	{
		model.addAttribute("cartCount", GlobalData.cart.size());
	   return "indexes";
	}
//	@GetMapping("/loginPage")
//	public String viewLoginPage(Model model) {
//		model.addAttribute("user", new User());
//		return "loginPage";
//	}
	
	@GetMapping("/random")
	public String viewRandomPage() {
		return "random";
	}

	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
		model.addAttribute("user", new User());
		return "register";
	}

	@GetMapping("/signup")
	public String showSignup(Model model) {
		model.addAttribute("user", new User());
		return "signup";
	}

	@GetMapping("/process_register")
	public String processRegister(User user) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
		char[] chars = "abcdefghijklmnopqrstuvwxyz1234567890".toCharArray();
		StringBuilder sb = new StringBuilder();
		Random random = new SecureRandom();
		for (int i = 0; i < 5; i++) {
			char c = chars[random.nextInt(chars.length)];
			sb.append(c);
		}
		String refCode = sb.toString();
		user.setReferralCode(refCode);
		userRepo.save(user);
		return "registeredSuccess";
	}

	@GetMapping("/users")
	public String listUsers(Model model) {
		List<User> listUsers = userRepo.findAll();
		model.addAttribute("listUsers", listUsers);
		return "users";
	}

	@GetMapping("/add_points")
	public int listUser(@PathVariable String referralCode) {
		
		int update=userRepo.setReferralPoints(referralCode);
		return update;
	}

}
