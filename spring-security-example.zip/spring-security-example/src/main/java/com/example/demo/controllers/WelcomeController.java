package com.example.demo.controllers;

import java.security.Principal;

import javax.annotation.security.RolesAllowed;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelcomeController 
{
	@GetMapping(path = "/payments")
	public String paymentDetails(Principal principal)
	{
		System.out.println("Current user: "+principal.getName());
		return "10-01-2023,iNR:5000";
	}
	
	@GetMapping(path = "/statement")
	@RolesAllowed(value = "ROLE_ADMIN")
	public String statement(Principal principal)
	{
		System.out.println("Current user: "+principal.getName());
		return "10-01-2023,INR:5000,12-01-2023,INR:7200";
	}
}
