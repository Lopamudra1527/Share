package com.example.demo.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableGlobalMethodSecurity(jsr250Enabled = true) // Used to enable method level security
public class SecurityConfig 
{
	@Autowired
	BCryptPasswordEncoder encoder;
	
	@Bean
	public UserDetailsManager details()
	{
		UserDetails nepalUser = User.withUsername("nepal").password(encoder.encode("nepal")).authorities("ROLE_ADMIN").build();
		UserDetails bhutanUser = User.withUsername("bhutan").password(encoder.encode("bhutan")).authorities("ROLE_USER").build();
		
		return new InMemoryUserDetailsManager(nepalUser,bhutanUser);

	}
	
	@Bean
	public SecurityFilterChain chain(HttpSecurity http) throws Exception
	{
//		http.csrf().disable().authorizeHttpRequests().antMatchers("/payments").permitAll()
//		.and().authorizeHttpRequests().antMatchers("/statement").hasAnyRole("ADMIN").authenticated().and().httpBasic();
		
//		http.csrf().disable().authorizeHttpRequests().antMatchers("/payments").permitAll()
//		.and().authorizeHttpRequests().antMatchers("/statement").hasAuthority("ADMIN").and().httpBasic();
		
//		Giving the hasAuthority in the method level using @EnableGlobalMethodSecurity and @RolesAllowed (Takes String array as input).
		http.csrf().disable().authorizeHttpRequests().antMatchers("/payments").permitAll()
		.and().authorizeHttpRequests().antMatchers("/statement").authenticated().and().httpBasic();
		
		return http.build();
	}
}
